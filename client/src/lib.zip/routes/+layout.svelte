<script>
  import "../app.css";
  import { useAuthState } from "$lib/states/authState.svelte.js";
  import Header from "$lib/components/layout/Header.svelte";
  let { children } = $props();
  const authState = useAuthState();
</script>

<div class="flex flex-col h-screen bg-secondary-100">
  <Header />

  <main class="container mx-auto px-4 grow bg-tertiary-50">
    {@render children()}
  </main>
</div>